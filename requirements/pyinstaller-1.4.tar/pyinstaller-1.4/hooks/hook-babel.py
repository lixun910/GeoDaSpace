from hooks.hookutils import babel_localedata_dir

hiddenimports = ["babel.dates"]

datas = [
    (babel_localedata_dir(), ""),
]
