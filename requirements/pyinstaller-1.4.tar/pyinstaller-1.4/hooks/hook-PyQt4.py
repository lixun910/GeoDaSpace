# In the new consolidated mode any PyQt depends on _qt
hiddenimports = ['sip', 'PyQt4._qt']
