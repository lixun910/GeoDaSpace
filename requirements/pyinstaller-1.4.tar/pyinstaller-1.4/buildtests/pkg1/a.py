""" pkg1.a.py is never imported """

print " %s" % __doc__
print " %s %s" % (__name__, __file__)
