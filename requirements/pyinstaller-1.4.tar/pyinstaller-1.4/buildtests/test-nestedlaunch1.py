import os
import sys
import subprocess
import datetime

if __name__ == "__main__":
    subprocess.check_call([os.path.dirname(sys.executable) + "/../test-nestedlaunch0/test-nestedlaunch0.exe"])
