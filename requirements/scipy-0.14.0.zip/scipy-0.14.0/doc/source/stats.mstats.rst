.. automodule:: scipy.stats.mstats
