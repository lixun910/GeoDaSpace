.. automodule:: scipy.linalg

.. toctree::
   :hidden:

   linalg.blas
   linalg.lapack
   linalg.interpolative
