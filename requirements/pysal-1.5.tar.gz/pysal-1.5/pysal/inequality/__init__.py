"""
:mod:`inequality` --- Spatial Inequality Analysis
=================================================

"""
